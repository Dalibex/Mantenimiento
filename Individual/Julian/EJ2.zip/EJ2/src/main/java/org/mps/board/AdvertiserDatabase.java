package org.mps.board;

/**
 * @author Antonio J. Nebro
 */
public interface AdvertiserDatabase {
    boolean advertiserIsRegistered(String advertiserName);
}
