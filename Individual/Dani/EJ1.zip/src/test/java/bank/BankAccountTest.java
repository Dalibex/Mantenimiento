package bank;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class BankAccountTest {
    
    private BankAccount bankAccount;
    @BeforeEach
    void setup() {
        bankAccount = new BankAccount(10);
    }

    @Test
    @DisplayName("Withdraw devuelve true si la cantidad a sacar es menor o igual a la que hay en el banco y false en caso contrario")
    void Withdraw_ReturnsConsistentBoolean() {
        assertTrue(bankAccount.withdraw(10), "Debe devolver true ya que hay 10 y retiramos 10");
        assertFalse(bankAccount.withdraw(10), "Debe devolver false ya que ahora hay 0 y retiramos 10");
    }

    @Test
    @DisplayName("Withdraw reduce correctamente el saldo si hay fondos suficientes")
    void Withdraw_ReducesBalanceWhenSuccessful() {
        bankAccount.withdraw(10);
        assertEquals(0, bankAccount.getBalance(), "El saldo debe reducirse correctamente tras un retiro exitoso");
    }

    @Test
    @DisplayName("Deposit lanza una excepción si el monto es negativo")
    void Deposit_NegativeDeposit_ThrowsException() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> bankAccount.deposit(-10));
        assertEquals("Amount cannot be negative", ex.getMessage());
    }

    @Test
    @DisplayName("Deposit suma correctamente al saldo")
    void Deposit_CorrectDeposit_AddsToBalance() {
        bankAccount.deposit(50);
        assertEquals(60, bankAccount.getBalance(), "El saldo debe aumentar correctamente tras un depósito");
    }

    @Test
    @DisplayName("getBalance devuelve el saldo correcto")
    void GetBalance_ReturnsCorrectBalance() {
        assertEquals(10, bankAccount.getBalance(), "El saldo inicial debe ser correcto");
        bankAccount.deposit(100);
        assertEquals(110, bankAccount.getBalance(), "El saldo se ha actualizado y devuelve la cantidad correctamente");
    }

    @Test
    @DisplayName("Loan payment calcula correctamente el pago mensual")
    void Payment_CalculatesCorrectly() {
        double totalAmount = 10000;
        double interest = 0.01;
        int months = 12;

        double expectedPayment = totalAmount * (interest * Math.pow(1 + interest, months) / (Math.pow(1 + interest, months) - 1));

        assertEquals(expectedPayment, bankAccount.payment(totalAmount, interest, months), 0.01, "El cálculo del pago mensual debe ser correcto");
    }

    @Test
    @DisplayName("Pending calcula correctamente el saldo restante de un préstamo")
    void pending_CalculatesCorrectly() {
        double totalAmount = 10000;
        double interest = 0.01;
        int months = 12;
        int month = 2;
        
        double expectedPending = bankAccount.pending(totalAmount, interest, months, month);
        
        assertEquals(expectedPending, bankAccount.pending(totalAmount, interest, months, month), 0.01, "El cálculo del saldo restante debe ser correcto");
    }
}
