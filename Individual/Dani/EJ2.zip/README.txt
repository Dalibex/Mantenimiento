El test double tipo "Spy" se usa mayormente para verificar que se llaman ciertos métodos con parámetros específicos, pero en este caso
la idea del test es comprobar que se lanza una excepción, no tanto la llamada internamente al método, por lo que usar "Spy" no es
ideal en este caso.